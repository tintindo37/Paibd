<?php
    // Zamknięcie połączenia
    mysqli_close($conn);
?>
