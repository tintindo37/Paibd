<?php
echo "Nazwa bazy danych: " . mysqli_get_server_info($conn);
?>
